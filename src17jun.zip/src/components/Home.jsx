// Home.js
import React from 'react';

const Home = () => {
  return <h2>Welcome to the Home Page</h2>;
};

export default Home;
